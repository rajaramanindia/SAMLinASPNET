﻿using Saml;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class samlres : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string samlCertificate = ConfigurationManager.AppSettings["samlcert"];

            Saml.Response samlResponse = new Response(samlCertificate, Request.Form["SAMLResponse"]);

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using System.Xml;

namespace WebApplication1
{
    /// <summary>
    /// Summary description for AssertionConsumerHttpHandler1
    /// </summary>
    public class AssertionConsumerHttpHandler1 : IHttpHandler, IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            switch (context.Request.HttpMethod)
            {
                case "POST":
                    // Checking to verify that a SAML Assertion is included
                    if (context.Request.Params["SAMLResponse"] == null)
                    {
                        context.Response.Redirect("ServiceProviderError.aspx");
                    }

                    // Checking for the intended resource
                    if (context.Request.Params["RelayState"] == null)
                    {
                        context.Response.Redirect("ServiceProviderError.aspx");
                    }

                    // pull Base 64 encoded XML saml assertion from Request and decode it
                    XmlDocument SAMLXML = new XmlDocument();
                    String SAMLResponseString = System.Text.Encoding.UTF8.GetString(
                        Convert.FromBase64String(context.Request.Params["SAMLResponse"].ToString()));
                    SAMLXML.LoadXml(SAMLResponseString);

                    //// Validate X509 Certificate Signature
                    //if (!ValidateX509CertificateSignature(SAMLXML))
                    //{
                    //    context.Response.Redirect("ServiceProviderError.aspx");
                    //}

                    //// Finding 
                    //AssertionType assertion = GetAssertionFromXMLDoc(SAMLXML);
                    //if (assertion.Issuer.Value == ConfigurationManager.AppSettings["CertIssuer"])
                    //{
                    //    AssertionData SSOData = new AssertionData(assertion);
                    //}

                    // At this point any specific work that needs to be done to establish user context with
                    // the SSOData should be executed before redirecting the user browser to the target
                    context.Response.Redirect(context.Request.Params["RelayState"].ToString());

                    break;
            }

            context.Response.ContentType = "text/plain";
            context.Response.Write("Hello World");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
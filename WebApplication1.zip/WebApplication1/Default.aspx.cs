﻿using Saml;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography.Xml;
using System.Web.Services;

namespace WebApplication1
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            

            //object ssss = HttpContext.Current.Request.Form["SAMLResponse"];

            string samlCertificate = ConfigurationManager.AppSettings["samlcert"];

            Saml.Response samlResponse = new Response(samlCertificate, Request.Form["SAMLResponse"]);

            // 3. DONE!
            if (samlResponse.IsValid()) //all good?
            {
     
                try
                {
                    var username = samlResponse.GetNameID();
                    var email = samlResponse.GetEmail();
                    var firstname = samlResponse.GetFirstName();
                    var lastname = samlResponse.GetLastName();

                    //or read some custom-named data that you know the IdP sends
                    //var officeLocation = samlResponse.GetCustomAttribute("OfficeAddress");


                    TextBox1.Text = "Login Name: " + username+"/n Email: " + email + "/n First Name: " + firstname + "/n Last Name: " + lastname + "/n";
                }
                catch (Exception ex)
                {
                    //insert error handling code
                    //in case some extra attributes are not present in XML, for example
                    
                }


            }

        }

        [WebMethod]
        public static void SendCustomResponse()
        {
            HttpResponse response = HttpContext.Current.Response;

            object ssss = HttpContext.Current.Request.Form["SAMLResponse"];

        }
    }
}